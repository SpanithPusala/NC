console.log('[DEBUG] script running...')

// animation step number input
let stepCtrl

function onLoad() {
    animation.resizeDrawingSurfaceToCanvas()

    const inputs = animation.stateMachineInputs('State Machine')
    stepCtrl = inputs.find((i) => i.name === 'steps')
}

// load animation
let animation

function loadAnimation() {
    animation = new rive.Rive({
        src: 'build-vs-buy.riv',
        canvas: document.getElementById('build-vs-buy'),
        autoplay: true,
        layout: new rive.Layout({
            fit: rive.Fit.Contain,
        }),
        artboard: window.innerWidth > 800 ? 'Desktop' : 'Mobile',
        stateMachines: 'State Machine',
        onLoad: onLoad,
    })
}
loadAnimation()
// change animation on scroll
// desired scroll increment can be used
// like every x pixels scrolled increases steps
// here dividing the scrollarea by 14 i.e. total steps
const scrollParent = document.querySelector('main')
const scrollIncrement = (scrollParent.scrollHeight - window.innerHeight) / 14

console.log(scrollParent.scrollHeight - window.innerHeight)
console.log(scrollIncrement)

let currentStep = 0

window.addEventListener("scroll", () => {
    currentStep = Math.floor(window.scrollY / scrollIncrement)

    stepCtrl.value = currentStep
    // if (currentStep > stepCtrl.value) {
    // }
})

// catch skip event
animation.on(
    rive.EventType.RiveEvent,
    (riveEvent) => {
        // scroll to 13th step
        window.scrollTo(0, scrollIncrement * 13)

        console.log("Skip Event")
    }
)

// onresize
const btn = document.querySelector('a.cta')
let isMobile = window.innerWidth < 800

window.addEventListener("resize", () => {
    if (isMobile != window.innerWidth < 800) {
        loadAnimation()
        isMobile = window.innerWidth < 800
    }
    animation.resizeDrawingSurfaceToCanvas()
})